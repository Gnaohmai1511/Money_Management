import 'package:flutter/material.dart';
import '../widgets/login_widgets/custom_text_field.dart';
import '../widgets/login_widgets/custom_button.dart';
import '../models/user_model_login.dart';
import '../services/user_services.dart';

import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  void _handleRegister() async {
    if (!_emailController.text.contains('@')) {
      _showSnackBar("Invalid email format");
      return;
    }

    if (_passwordController.text.length < 6) {
      _showSnackBar("Password must be at least 6 characters");
      return;
    }

    if (_passwordController.text != _confirmPasswordController.text) {
      _showSnackBar("Passwords do not match");
      return;
    }

    final newUser = UserModel(
      email: _emailController.text,
      username: _usernameController.text,
      password: _passwordController.text,
    );

    try {
      await UserService.saveUser(newUser);
      _showSnackBar("Registration successful");

      // Chuyển sang màn hình đăng nhập
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    } catch (e) {
      _showSnackBar(e.toString().replaceAll('Exception: ', ''));
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: const Text("Register"),
        backgroundColor: const Color(0xFFF2FCF7),
      ),
      backgroundColor: const Color(0xFFF2FCF7),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const Text(
                "Create Account",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 24),
              CustomTextField(label: "Email", controller: _emailController),
              const SizedBox(height: 12),
              CustomTextField(
                label: "Username",
                controller: _usernameController,
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: "Password",
                controller: _passwordController,
                obscureText: true,
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: "Confirm Password",
                controller: _confirmPasswordController,
                obscureText: true,
              ),
              const SizedBox(height: 20),
              CustomButton(label: "Register", onPressed: _handleRegister),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Text(
                  "Already have an account? Login",
                  style: TextStyle(color: Colors.green),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
