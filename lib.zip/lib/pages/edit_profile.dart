import 'dart:io';
import 'package:flutter/material.dart';

import '../utils/validators.dart';
import '../utils/constants.dart';
import '../services/shared_preferences.dart';
import '../services/user_services.dart';
import '../widgets/edit_widgets/profile_image_picker.dart';
import '../widgets/edit_widgets/custom_text_field.dart';
import '../widgets/edit_widgets/date_picker_field.dart';
import '../widgets/edit_widgets/country_picker_field.dart';

class EditProfileScreen extends StatefulWidget {
  final VoidCallback? onAvatarChanged; // callback báo avatar thay đổi

  const EditProfileScreen({super.key, this.onAvatarChanged});

  @override
  // ignore: library_private_types_in_public_api
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  File? _profileImage;
  DateTime? _selectedDate;
  String? _selectedCountry;
  bool _obscurePassword = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final userData = await SharedPrefs().loadUserProfile();

    String email = userData['email'] ?? '';
    String password = userData['password'] ?? '';
    String name = userData['name'] ?? '';
    if (email.isNotEmpty) {
      final users = await UserService.getAllUsers();
      final user = users.where((u) => u.email == email).toList();
      if (user.isNotEmpty) {
        password = user.first.password;
      }
    }
    // --------------------------------------------------

    setState(() {
      _emailController.text = email;
      _nameController.text = name;
      _passwordController.text = password;

      _selectedDate = userData['dateOfBirth'];
      _selectedCountry = userData['country'];

      final imagePath = userData['profileImagePath'];
      if (imagePath != null && imagePath.isNotEmpty) {
        _profileImage = File(imagePath);
      }
    });
  }

  void _onImageSelected(File image) {
    setState(() {
      _profileImage = image;
    });
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _onCountrySelected(String country) {
    setState(() {
      _selectedCountry = country;
    });
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await SharedPrefs().saveUserProfile(
        name: _nameController.text,
        email: _emailController.text,
        password: _passwordController.text,
        dateOfBirth: _selectedDate,
        country: _selectedCountry,
        profileImagePath: _profileImage?.path,
      );

      // Nếu avatar thay đổi, gọi callback báo ra ngoài
      if (widget.onAvatarChanged != null) {
        widget.onAvatarChanged!();
      }

      _showMessage('Profile updated successfully!', Colors.green);
    } catch (e) {
      _showMessage('Error: ${e.toString()}', Colors.red);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showMessage(String message, Color color) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message), backgroundColor: color));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2FCF7),
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Edit Profile',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: const Color(0xFFF2FCF7),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Profile Image
              ProfileImagePicker(
                profileImage: _profileImage,
                onImageSelected: _onImageSelected,
              ),
              SizedBox(height: 40),

              // Name Field
              CustomTextField(
                label: 'Name',
                hintText: 'Enter your name',
                controller: _nameController,
                validator: Validators.validateName,
              ),
              SizedBox(height: 20),

              // Email Field
              TextFormField(
                controller: _emailController,
                readOnly: true,
                decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: 'Your email',
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.grey),
              ),
              SizedBox(height: 20),

              // Password Field
              CustomTextField(
                label: 'Password',
                hintText: 'Enter your password',
                controller: _passwordController,
                validator: Validators.validatePassword,
                obscureText: _obscurePassword,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off : Icons.visibility,
                    color: AppConstants.hintColor,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
              ),
              SizedBox(height: 20),

              // Date of Birth Field
              DatePickerField(
                label: 'Date of Birth',
                selectedDate: _selectedDate,
                onTap: _selectDate,
              ),
              SizedBox(height: 20),

              // Country Field
              CountryPickerField(
                label: 'Country/Region',
                selectedCountry: _selectedCountry,
                onCountrySelected: _onCountrySelected,
              ),
              SizedBox(height: 40),

              // Save Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveChanges,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppConstants.primaryColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child:
                      _isLoading
                          ? CircularProgressIndicator(color: Colors.white)
                          : Text(
                            'Save changes',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
