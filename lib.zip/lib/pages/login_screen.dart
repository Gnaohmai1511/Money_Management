import 'package:flutter/material.dart';
import 'package:money_management/pages/expense_management_page.dart';
import 'package:money_management/services/shared_preferences.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/login_widgets/custom_text_field.dart';
import '../widgets/login_widgets/remember_me_checkbox.dart';
import '../widgets/login_widgets/custom_button.dart';
import 'register_screen.dart';
import '../models/user_model_login.dart';
import '../services/user_services.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _rememberMe = false;

  @override
  void initState() {
    super.initState();
    _loadSavedLogin();
  }

  void _loadSavedLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool remember = prefs.getBool('remember_me') ?? false;
    if (remember) {
      String? email = prefs.getString('email');
      String? password = prefs.getString('password');
      setState(() {
        _rememberMe = remember;
        _emailController.text = email ?? '';
        _passwordController.text = password ?? '';
      });
      // _navigateToHome();
    }
  }

  void _handleLogin() async {
    if (!_emailController.text.contains('@')) {
      _showSnackBar("Invalid email");
      return;
    }

    UserModel? user = await UserService.authenticate(
      _emailController.text,
      _passwordController.text,
    );

    if (user == null) {
      _showSnackBar("Invalid credentials");
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedName = prefs.getString(SharedPrefs.keyName);
    if (savedName != null &&
        savedName.isNotEmpty &&
        savedName != user.username) {
      user = UserModel(
        email: user.email,
        password: user.password,
        username: savedName,
      );
    }

    await SharedPrefs.saveUser(user);

    if (_rememberMe) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('remember_me', true);
      await prefs.setString('email', user.email);
      await prefs.setString('password', user.password);
    }

    _navigateToHome();
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _navigateToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const ExpenseManagementPage()),
    );
  }

  void _handleRegister() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const RegisterScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFFF2FCF7),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Sign in",
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            CustomTextField(label: "Email", controller: _emailController),
            const SizedBox(height: 12),
            CustomTextField(
              label: "Password",
              controller: _passwordController,
              obscureText: true,
            ),
            Row(
              children: [
                RememberMeCheckbox(
                  value: _rememberMe,
                  onChanged: (value) {
                    setState(() {
                      _rememberMe = value ?? false;
                    });
                  },
                ),
                const Spacer(),
              ],
            ),
            CustomButton(label: "Login", onPressed: _handleLogin),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: _handleRegister,
              child: const Text(
                "Don’t have an account? Register",
                style: TextStyle(color: Colors.green),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
