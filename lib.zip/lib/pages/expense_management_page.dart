import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:money_management/components/fm_app_bar.dart';
import 'package:money_management/components/fm_card.dart';
import 'package:money_management/resources/app_color.dart';
import 'package:money_management/models/transaction_model.dart';
import 'package:money_management/components/app_dialog.dart';
import 'package:money_management/services/shared_preferences.dart';

class ExpenseManagementPage extends StatefulWidget {
  const ExpenseManagementPage({super.key});

  @override
  State<ExpenseManagementPage> createState() => _ExpenseManagementPageState();
}

class _ExpenseManagementPageState extends State<ExpenseManagementPage> {
  late List<TransactionModel> transactions;

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  Map<String, List<TransactionModel>> groupTransactionsByDate() {
    Map<String, List<TransactionModel>> grouped = {};
    for (var tx in transactions) {
      final dateKey = DateFormat(
        'dd/MM/yyyy',
      ).format(tx.date ?? DateTime.now());
      if (!grouped.containsKey(dateKey)) grouped[dateKey] = [];
      grouped[dateKey]!.add(tx);
    }
    return grouped;
  }

  double get totalIncome => transactions
      .where((tx) => tx.isIncome == true)
      .fold(0, (sum, tx) => sum + (tx.amount ?? 0));

  double get totalExpense => transactions
      .where((tx) => tx.isIncome == false)
      .fold(0, (sum, tx) => sum + (tx.amount ?? 0));

  void _addTransaction() async {
    final newTx = await AppDialog.addTransaction(context);
    if (newTx != null) {
      setState(() => transactions.add(newTx));
      await SharedPrefs.savetransactions(transactions);
    }
  }

  void _editTransaction(TransactionModel tx) async {
    final updatedTx = await AppDialog.editTransaction(context, tx);
    final index = transactions.indexOf(tx);
    if (index != -1) {
      setState(() {
        transactions[index] = updatedTx;
      });
      await SharedPrefs.savetransactions(transactions);
    }
  }

  void _deleteTransaction(TransactionModel tx) async {
    final confirm = await AppDialog.deleteTransaction(context, tx);
    if (confirm) {
      setState(() => transactions.remove(tx));
      await SharedPrefs.savetransactions(transactions);
    }
  }

  void _loadTransactions() async {
    final savedTxs = await SharedPrefs.gettransactions();
    setState(() {
      transactions = savedTxs;
    });
  }

  @override
  Widget build(BuildContext context) {
    final groupedTransactions = groupTransactionsByDate();
    final dateKeys =
        groupedTransactions.keys.toList()..sort((a, b) {
          final dateA = DateFormat('dd/MM/yyyy').parse(a);
          final dateB = DateFormat('dd/MM/yyyy').parse(b);
          return dateB.compareTo(dateA);
        });

    return Scaffold(
      backgroundColor: const Color(0xFFF2FCF7),
      appBar: FmAppBar(transactions: transactions),
      floatingActionButton: FloatingActionButton(
        onPressed: _addTransaction,
        child: const Icon(Icons.add),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                children: [
                  Expanded(
                    child: FmCard(
                      title: 'Income',
                      amount: '\$${totalIncome.toStringAsFixed(2)}',
                      icon: Icons.arrow_upward,
                      backgroundGradient: AppColors.incomeGradient,
                    ),
                  ),
                  const SizedBox(width: 3),
                  Expanded(
                    child: FmCard(
                      title: 'Expenditure',
                      amount: '\$${totalExpense.toStringAsFixed(2)}',
                      icon: Icons.arrow_downward,
                      backgroundGradient: AppColors.expenseGradient,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children:
                    dateKeys.map((dateKey) {
                      final dailyTransactions = groupedTransactions[dateKey]!;

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dateKey,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 8),

                          ...dailyTransactions.map((tx) {
                            return Card(
                              elevation: 1,
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor:
                                      tx.isIncome!
                                          ? AppColors
                                              .incomeGradient
                                              .colors
                                              .first
                                          : AppColors
                                              .expenseGradient
                                              .colors
                                              .first,
                                  child: Text(
                                    tx.initials ?? '',
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                                title: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            tx.name ?? '',
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            tx.time ?? '',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    Text(
                                      '${tx.isIncome! ? '+' : '-'}\$${(tx.amount ?? 0).toStringAsFixed(2)}',
                                      style: TextStyle(
                                        color:
                                            tx.isIncome!
                                                ? Colors.green
                                                : Colors.red,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),

                                    IconButton(
                                      icon: const Icon(
                                        Icons.edit,
                                        color: Colors.blue,
                                        size: 20,
                                      ),
                                      onPressed: () => _editTransaction(tx),
                                      padding: EdgeInsets.zero,
                                      constraints: const BoxConstraints(),
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                        size: 20,
                                      ),
                                      onPressed: () => _deleteTransaction(tx),
                                      padding: EdgeInsets.zero,
                                      constraints: const BoxConstraints(),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),

                          const SizedBox(height: 20),
                        ],
                      );
                    }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
