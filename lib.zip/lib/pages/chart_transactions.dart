import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:money_management/models/transaction_model.dart';
import 'package:money_management/resources/app_color.dart';

class ExpenseChartPage extends StatelessWidget {
  final List<TransactionModel> transactions;

  const ExpenseChartPage({super.key, required this.transactions});

  @override
  Widget build(BuildContext context) {
    // Gom nhóm dữ liệu theo tháng
    Map<String, double> incomeByMonth = {};
    Map<String, double> expenseByMonth = {};

    for (var tx in transactions) {
      final monthKey = DateFormat('MM/yyyy').format(tx.date ?? DateTime.now());
      if (tx.isIncome == true) {
        incomeByMonth[monthKey] =
            (incomeByMonth[monthKey] ?? 0) + (tx.amount ?? 0);
      } else {
        expenseByMonth[monthKey] =
            (expenseByMonth[monthKey] ?? 0) + (tx.amount ?? 0);
      }
    }

    final List<String> months = List.generate(
      12,
      (i) => DateFormat('MM/yyyy').format(DateTime(DateTime.now().year, i + 1)),
    );

    final List<MonthlyData> chartData =
        months
            .map(
              (month) => MonthlyData(
                month,
                incomeByMonth[month] ?? 0,
                expenseByMonth[month] ?? 0,
              ),
            )
            .toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF2FCF7),
      appBar: AppBar(
        title: const Text('Monthly Income & Expenditure Chart'),
        backgroundColor: const Color(0xFFF2FCF7),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: SfCartesianChart(
          backgroundColor: const Color(0xFFF2FCF7),
          title: ChartTitle(text: 'Income & Expenditure (Monthly)'),
          legend: Legend(isVisible: true, position: LegendPosition.bottom),
          tooltipBehavior: TooltipBehavior(enable: true),
          primaryXAxis: CategoryAxis(
            interval: 1,
            labelRotation: 45,
            title: AxisTitle(text: 'Month'),
          ),
          primaryYAxis: NumericAxis(
            labelFormat: '\${value}',
            title: AxisTitle(text: 'Amount'),
            minimum: 0,
          ),
          series: <CartesianSeries>[
            ColumnSeries<MonthlyData, String>(
              name: 'Income',
              dataSource: chartData,
              xValueMapper: (data, _) => data.month,
              yValueMapper: (data, _) => data.income,
              color: AppColors.incomeGradient.colors.first,
              dataLabelSettings: const DataLabelSettings(isVisible: true),
            ),
            ColumnSeries<MonthlyData, String>(
              name: 'Expenditure',
              dataSource: chartData,
              xValueMapper: (data, _) => data.month,
              yValueMapper: (data, _) => data.expenditure,
              color: AppColors.expenseGradient.colors.first,
              dataLabelSettings: const DataLabelSettings(isVisible: true),
            ),
          ],
        ),
      ),
    );
  }
}

class MonthlyData {
  final String month;
  final double income;
  final double expenditure;

  MonthlyData(this.month, this.income, this.expenditure);
}
