import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFF006231);
  static const appTitle = Color(0xFFFBDE08);
  static const addButton = Color(0xFF007AFF);
  static const transIncome = Color(0xFF36B269);
  static const transExpense = Color(0xFFE54545);
  static const lightPeriwinkle = Color(0xFF9B9CF8);
  static const mediumPeriwinkle = Color(0xFF8082ED);
  static const Color lightPink = Color(0xFFFEB4C5);
  static const Color deepPink = Color(0xFFDB869A);
  static const incomeGradient = RadialGradient(
    colors: [lightPeriwinkle, mediumPeriwinkle],
    center: Alignment.center,
    radius: 0.8,
  );
  static const RadialGradient expenseGradient = RadialGradient(
    colors: [lightPink, deepPink],
    center: Alignment.center,
    radius: 0.8,
  );
}
