class OnboardingPageModel {
  final String image;
  final String title;
  final String description;

  OnboardingPageModel({
    required this.image,
    required this.title,
    required this.description,
  });
}

final List<OnboardingPageModel> pages = [
  OnboardingPageModel(
    image: 'assets/images/anh-meme-tien-ba-dao_093839638.jpg',
    title: 'Welcome!',
    description: 'Chào mừng đến với app quản lý tài chính.',
  ),
  OnboardingPageModel(
    image: 'assets/images/gintama-meme.jpg',
    title: 'Mục tiêu',
    description:
        'Đây là ứng dụng giúp bạn quản lý được chi tiêu hàng ngày một cách hiệu quả và đạt được các mục tiêu tài chính cá nhân.',
  ),
  OnboardingPageModel(
    image: 'assets/images/home.jpg',
    title: 'Tính năng',
    description:
        'Với các tính năng như liệt kê chi tiêu, tính tổng chi tiêu trên giao diện thân thiện, bạn sẽ dễ dàng theo dõi và quản lý tài chính cá nhân của mình.',
  ),
  OnboardingPageModel(
    image: 'assets/images/5b761c22-bac2-4684-8f95-76ecd51c3d4e.jpg',
    title: 'Thống kê',
    description:
        'Tính năng thống kê giúp bạn theo dõi và phân tích chi tiêu của mình theo thời gian, từ đó đưa ra quyết định tài chính thông minh hơn.',
  ),
  OnboardingPageModel(
    image: 'assets/images/add_transaction.jpg',
    title: 'Thêm giao dịch',
    description:
        'Có thể thêm giao dịch chi tiêu hoặc thu nhập một cách nhanh chóng và dễ dàng chỉ với một nút bấmbấm . Chỉ cần nhập số tiền, tên giao dịch và chọn loại giao dịch.',
  ),
  OnboardingPageModel(
    image: 'assets/images/profile.jpg',
    title: 'Profile',
    description:
        'Tính năng Hồ sơ cá nhân cho phép người dùng quản lý thông tin cá nhân, cài đặt ứng dụng và theo dõi hoạt động tài chính của họ. Tại đây, người dùng có thể cập nhật tên, email, ảnh đại diện  và hỗ trợ đăng xuất hoặc xoá tài khoản',
  ),
];
