class UserModel {
  final String? name;
  final String? email;
  final String? password;
  final DateTime? dateOfBirth;
  final String? country;
  final String? profileImagePath;

  UserModel({
    this.name,
    this.email,
    this.password,
    this.dateOfBirth,
    this.country,
    this.profileImagePath,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'password': password,
      'date_of_birth': dateOfBirth?.toIso8601String(),
      'country': country,
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      name: json['name'],
      email: json['email'],
      password: json['password'],
      dateOfBirth:
          json['date_of_birth'] != null
              ? DateTime.parse(json['date_of_birth'])
              : null,
      country: json['country'],
      profileImagePath: json['profile_image_path'],
    );
  }

  UserModel copyWith({
    String? name,
    String? email,
    String? password,
    DateTime? dateOfBirth,
    String? country,
    String? profileImagePath,
  }) {
    return UserModel(
      name: name ?? this.name,
      email: email ?? this.email,
      password: password ?? this.password,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      country: country ?? this.country,
      profileImagePath: profileImagePath ?? this.profileImagePath,
    );
  }
}
