class TransactionModel {
  String? name;
  String? time;
  double? amount;
  String? initials;
  bool? isIncome;
  DateTime? date;

  TransactionModel({
    this.name,
    this.time,
    this.amount,
    this.initials,
    this.isIncome,
    this.date,
  });

  TransactionModel copyWith({
    String? name,
    String? time,
    double? amount,
    String? initials,
    bool? isIncome,
    DateTime? date,
  }) {
    return TransactionModel(
      name: name ?? this.name,
      time: time ?? this.time,
      amount: amount ?? this.amount,
      initials: initials ?? this.initials,
      isIncome: isIncome ?? this.isIncome,
      date: date ?? this.date,
    );
  }

  TransactionModel.fromJson(Map<String, dynamic> json) {
    name = json['name'] as String;
    time = json['time'] as String;
    amount = (json['amount'] as num).toDouble();
    initials = json['initials'] as String;
    isIncome = json['isIncome'] as bool;
    date = DateTime.parse(json['date']);
  }
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'time': time,
      'amount': amount,
      'initials': initials,
      'isIncome': isIncome,
      'date': date?.toIso8601String(),
    };
  }
}
