import 'package:flutter/material.dart';
import '../../utils/constants.dart';

class DatePickerField extends StatelessWidget {
  final String label;
  final DateTime? selectedDate;
  final VoidCallback onTap;

  // ignore: use_super_parameters
  const DatePickerField({
    Key? key,
    required this.label,
    this.selectedDate,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: AppConstants.textColor,
          ),
        ),
        SizedBox(height: 8),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  selectedDate != null
                      ? '${selectedDate!.day.toString().padLeft(2, '0')}/${selectedDate!.month.toString().padLeft(2, '0')}/${selectedDate!.year}'
                      : 'Select date of birth',
                  style: TextStyle(
                    fontSize: 16,
                    color:
                        selectedDate != null
                            ? AppConstants.textColor
                            : AppConstants.hintColor,
                  ),
                ),
                Icon(Icons.keyboard_arrow_down, color: AppConstants.hintColor),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
