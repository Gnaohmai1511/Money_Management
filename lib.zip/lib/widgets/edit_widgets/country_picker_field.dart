import 'package:flutter/material.dart';
import '../../utils/constants.dart';

class CountryPickerField extends StatelessWidget {
  final String label;
  final String? selectedCountry;
  final Function(String) onCountrySelected;

  const CountryPickerField({
    super.key,
    required this.label,
    this.selectedCountry,
    required this.onCountrySelected,
  });

  void _showCountryPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        // ignore: sized_box_for_whitespace
        return Container(
          height: 300,
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Select Country',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: AppConstants.countries.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(AppConstants.countries[index]),
                      onTap: () {
                        onCountrySelected(AppConstants.countries[index]);
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: AppConstants.textColor,
          ),
        ),
        SizedBox(height: 8),
        GestureDetector(
          onTap: () => _showCountryPicker(context),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  selectedCountry ?? 'Select country',
                  style: TextStyle(
                    fontSize: 16,
                    color:
                        selectedCountry != null
                            ? AppConstants.textColor
                            : AppConstants.hintColor,
                  ),
                ),
                Icon(Icons.keyboard_arrow_down, color: AppConstants.hintColor),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
