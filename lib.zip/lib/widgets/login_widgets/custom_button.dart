import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const CustomButton({
    super.key,
    required this.label,
    required this.onPressed,
  });

  @override
 Widget build(BuildContext context) {
  return Row(
    children: [
      Expanded(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green[900]),
          onPressed: onPressed,
          child: Text(
          label,
          style: TextStyle(
          fontSize: 18,              // chữ to vừa phải
          fontWeight: FontWeight.bold,  // chữ đậm hơn
          color: Colors.white,       // màu chữ rõ trên nền xanh đậm
          letterSpacing: 1.2,        // khoảng cách chữ hơi rộng
),
),
        ),
      ),
    ],
  );
}
}