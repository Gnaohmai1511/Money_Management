import 'dart:io';
import 'package:flutter/material.dart';

class FmAvatar extends StatelessWidget {
  const FmAvatar({
    super.key,
    required this.avatar,
    this.radius = 26.0,
    this.isActive = false,
  });

  final String? avatar;
  final double radius;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CircleAvatar(
          backgroundColor: Colors.black,
          radius: radius,
          child: CircleAvatar(
            backgroundImage:
                avatar == null
                    ? const AssetImage('assets/images/avatar_default.png')
                        as ImageProvider
                    : FileImage(File(avatar!)),
            radius: radius - 1.0,
          ),
        ),
      ],
    );
  }
}
