import 'package:flutter/material.dart';
import 'package:money_management/models/transaction_model.dart';
import 'package:intl/intl.dart';
import '../utils/initials.dart';

class AppDialog {
  // ignore: non_constant_identifier_names
  static Future<void> ConfirmDialog(
    BuildContext context, {
    Widget? title,
    required String content,
    Function()? action,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: title,
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(
                  content,
                  style: const TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                action?.call();
                Navigator.of(context).pop();
              },
              child: const Text('Yes', style: TextStyle(fontSize: 16.0)),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('No', style: TextStyle(fontSize: 16.0)),
            ),
          ],
        );
      },
    );
  }

  static Future<TransactionModel> editTransaction(
    BuildContext context,
    TransactionModel transaction,
  ) async {
    final TextEditingController amountController = TextEditingController(
      text: transaction.amount?.toString() ?? '',
    );
    final TextEditingController nameController = TextEditingController(
      text: transaction.name ?? '',
    );

    bool isIncome = transaction.isIncome ?? false;
    DateTime selectedDate = transaction.date ?? DateTime.now();

    return showDialog<TransactionModel?>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Chỉnh sửa giao dịch'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: amountController,
                      keyboardType: TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: InputDecoration(labelText: 'Số tiền'),
                    ),
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: 'Tên giao dịch'),
                      onChanged: (_) => setState(() {}),
                    ),
                    SizedBox(height: 12),
                    ListTile(
                      title: Text(
                        'Ngày: ${DateFormat('dd/MM/yyyy').format(selectedDate)}',
                      ),
                      trailing: const Icon(Icons.calendar_today),
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: selectedDate,
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (picked != null) {
                          setState(() => selectedDate = picked);
                        }
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          children: [
                            Radio<bool>(
                              value: false,
                              groupValue: isIncome,
                              onChanged: (val) {
                                setState(() => isIncome = val!);
                              },
                            ),
                            const Text('Chi tiêu'),
                          ],
                        ),
                        Row(
                          children: [
                            Radio<bool>(
                              value: true,
                              groupValue: isIncome,
                              onChanged: (val) {
                                setState(() => isIncome = val!);
                              },
                            ),
                            const Text('Thu nhập'),
                          ],
                        ),
                      ],
                    ),

                    if (nameController.text.isNotEmpty)
                      Text(
                        'Chữ cái viết tắt: ${getInitials(nameController.text)}',
                      ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  child: Text('Hủy'),
                  onPressed: () => Navigator.of(context).pop(transaction),
                ),
                ElevatedButton(
                  child: Text('Lưu'),
                  onPressed: () {
                    final amount = double.tryParse(
                      amountController.text.trim(),
                    );
                    final rawAmount = amountController.text.trim();

                    final validate = RegExp(r'^\d+(\.\d+)?$');
                    final name = nameController.text.trim();
                    if (!validate.hasMatch(rawAmount)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Vui lòng nhập số')),
                      );
                      return;
                    }
                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Vui lòng nhập tên giao dịch'),
                        ),
                      );
                      return;
                    }

                    final editedTransaction =
                        transaction
                          ..amount = amount
                          ..name = name
                          ..initials = getInitials(name)
                          ..isIncome = isIncome
                          ..date = selectedDate
                          ..time = DateFormat('HH:mm').format(DateTime.now());
                    Navigator.of(context).pop(editedTransaction);
                  },
                ),
              ],
            );
          },
        );
      },
    ).then((value) => value ?? transaction);
  }

  static Future<TransactionModel?> addTransaction(BuildContext context) {
    final TextEditingController amountController = TextEditingController();
    final TextEditingController nameController = TextEditingController();

    bool isIncome = false;
    DateTime selectedDate = DateTime.now();
    return showDialog<TransactionModel?>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Thêm giao dịch mới'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: amountController,
                      keyboardType: TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: InputDecoration(labelText: 'Số tiền'),
                    ),
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: 'Tên giao dịch'),
                      onChanged: (_) {
                        setState(() {});
                      },
                    ),
                    ListTile(
                      title: Text(
                        'Ngày: ${DateFormat('dd/MM/yyyy').format(selectedDate)}',
                      ),
                      trailing: const Icon(Icons.calendar_today),
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: selectedDate,
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (picked != null) {
                          setState(() => selectedDate = picked);
                        }
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          children: [
                            Radio<bool>(
                              value: false,
                              groupValue: isIncome,
                              onChanged: (val) {
                                setState(() => isIncome = val!);
                              },
                            ),
                            const Text('Chi tiêu'),
                          ],
                        ),
                        Row(
                          children: [
                            Radio<bool>(
                              value: true,
                              groupValue: isIncome,
                              onChanged: (val) {
                                setState(() => isIncome = val!);
                              },
                            ),
                            const Text('Thu nhập'),
                          ],
                        ),
                      ],
                    ),

                    if (nameController.text.isNotEmpty)
                      Text(
                        'Chữ cái viết tắt: ${getInitials(nameController.text)}',
                      ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  child: Text('Hủy'),
                  onPressed: () => Navigator.of(context).pop(null),
                ),
                ElevatedButton(
                  child: Text('Lưu'),
                  onPressed: () {
                    final amount = double.tryParse(
                      amountController.text.trim(),
                    );
                    final rawAmount = amountController.text.trim();

                    final validate = RegExp(r'^\d+(\.\d+)?$');
                    if (!validate.hasMatch(rawAmount)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Vui lòng nhập số')),
                      );
                      return;
                    }
                    final name = nameController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Vui lòng nhập tên giao dịch'),
                        ),
                      );
                      return;
                    }
                    final newTransaction = TransactionModel(
                      amount: amount,
                      name: name,
                      initials: getInitials(name),
                      isIncome: isIncome,
                      date: selectedDate,
                      time: DateFormat('HH:mm').format(DateTime.now()),
                    );
                    Navigator.of(context).pop(newTransaction);
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  static Future<bool> deleteTransaction(
    BuildContext context,
    TransactionModel transaction,
  ) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Text('Xác nhận xoá'),
          content: Text(
            'Bạn có chắc muốn xóa giao dịch "${transaction.name ?? ''}" không?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('Huỷ'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text('Xóa'),
            ),
          ],
        );
      },
    ).then((value) => value ?? false);
  }
}
