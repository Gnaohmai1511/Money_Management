import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:money_management/models/transaction_model.dart';
import '../services/shared_preferences.dart';
import 'fm_avatar.dart';
import 'fm_setting_menu_button.dart';

class FmAppBar extends StatefulWidget implements PreferredSizeWidget {
  final List<TransactionModel> transactions;

  const FmAppBar({super.key, required this.transactions});

  @override
  Size get preferredSize => const Size.fromHeight(86.0);

  @override
  State<FmAppBar> createState() => _FmAppBarState();
}

class _FmAppBarState extends State<FmAppBar> {
  SharedPrefs prefs = SharedPrefs();
  String? avatar;

  @override
  void initState() {
    super.initState();
    _getAvatar();
  }

  Future<void> _pickAvatar() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );
    if (result != null) {
      String path = result.files.single.path!;
      await prefs.saveAvatarPath(path);
      await prefs.saveUserProfileImagePath(path);
      _getAvatar();
    }
  }

  Future<void> _getAvatar() async {
    avatar = await prefs.getAvatarPath();
    if (avatar != null && !(await File(avatar!).exists())) {
      avatar = null;
    }
    setState(() {});
  }

  Future<void> refreshAvatar() async {
    await _getAvatar();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF2FCF7),
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: MediaQuery.of(context).padding.top + 8,
        bottom: 12,
      ),
      child: Row(
        children: [
          GestureDetector(onTap: _pickAvatar, child: FmAvatar(avatar: avatar)),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              "Hello",
              style: TextStyle(
                fontSize: 30.0,
                fontFamily: 'DM Sans',
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          FmSettingMenuButton(
            onAvatarChanged: refreshAvatar,
            transactions: widget.transactions,
          ),
        ],
      ),
    );
  }
}
