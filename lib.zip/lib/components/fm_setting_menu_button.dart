import 'package:flutter/material.dart';
import 'package:money_management/models/transaction_model.dart';
import 'package:money_management/pages/chart_transactions.dart';
import 'package:money_management/pages/login_screen.dart';
import '../pages/edit_profile.dart';

class FmSettingMenuButton extends StatelessWidget {
  final VoidCallback? onAvatarChanged;
  final List<TransactionModel> transactions;
  const FmSettingMenuButton({
    super.key,
    this.onAvatarChanged,
    required this.transactions, // bắt buộc truyền vào
  });

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<int>(
      icon: const Icon(Icons.settings, color: Colors.black, size: 30),
      itemBuilder:
          (context) => [
            const PopupMenuItem<int>(
              value: 0,
              child: Row(
                children: [
                  Icon(Icons.person_outline),
                  SizedBox(width: 8),
                  Text("Edit profile"),
                ],
              ),
            ),
            const PopupMenuItem<int>(
              value: 1,
              child: Row(
                children: [
                  Icon(Icons.bar_chart),
                  SizedBox(width: 8),
                  Text("Chart"),
                ],
              ),
            ),
            const PopupMenuItem<int>(
              value: 2,
              child: Row(
                children: [
                  Icon(Icons.logout),
                  SizedBox(width: 8),
                  Text("Log out"),
                ],
              ),
            ),
          ],
      onSelected: (value) {
        if (value == 0) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (_) => EditProfileScreen(onAvatarChanged: onAvatarChanged),
            ),
          );
        } else if (value == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ExpenseChartPage(transactions: transactions),
            ),
          );
        } else if (value == 2) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const LoginScreen()),
            (Route<dynamic> route) => false, // Xóa toàn bộ stack
          );
        }
      },
    );
  }
}
