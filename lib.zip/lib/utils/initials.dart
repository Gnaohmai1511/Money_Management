String getInitials(String name) {
  if (name.trim().isEmpty) return '';
  final Words = name.trim().split(RegExp(r'\s+'));
  String initials = '';
  for (var w in Words) {
    if (w.isNotEmpty) {
      initials += w[0].toUpperCase();
    }
  }
  return initials;
}
