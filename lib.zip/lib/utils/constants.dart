import 'package:flutter/material.dart';

class AppConstants {
  // API Configuration
  static const String apiBaseUrl = 'https://your-api-endpoint.com';
  static const String authToken = 'your-token-here';

  // Colors
  static const Color primaryColor = Color(0xFF4A4A8A);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color textColor = Colors.black87;
  static const Color hintColor = Colors.grey;

  // Countries List
  static const List<String> countries = [
    'Nigeria',
    'United States',
    'United Kingdom',
    'Canada',
    'Australia',
    'Germany',
    'France',
    'Japan',
    'Brazil',
    'India',
    'South Africa',
    'Egypt',
    'Kenya',
    'Ghana',
    'Morocco',
  ];

  // Default Values
  static const String defaultAvatarPath = 'assets/images/default_avatar.png';
}
