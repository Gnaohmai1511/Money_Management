import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model_login.dart';

class UserService {
  static const _userListKey = 'user_list';

  static Future<List<UserModel>> getAllUsers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString(_userListKey);
    if (data == null) return [];

    List<dynamic> jsonList = json.decode(data);
    return jsonList.map((e) => UserModel.fromJson(e)).toList();
  }

  static Future<void> saveUser(UserModel user) async {
    List<UserModel> users = await getAllUsers();

    // Kiểm tra nếu email đã tồn tại
    bool exists = users.any((u) => u.email == user.email);
    if (!exists) {
      users.add(user);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String encoded = json.encode(users.map((e) => e.toJson()).toList());
      await prefs.setString(_userListKey, encoded);
    } else {
      throw Exception('Email already exists please check your email');
    }
  }

  static Future<UserModel?> authenticate(String email, String password) async {
    List<UserModel> users = await getAllUsers();
    try {
      return users.firstWhere(
        (user) => user.email == email && user.password == password,
      );
    } catch (_) {
      return null;
    }
  }

  // Thêm hàm cập nhật password cho user
  static Future<void> updateUserPassword(
    String email,
    String newPassword,
  ) async {
    List<UserModel> users = await getAllUsers();
    for (var i = 0; i < users.length; i++) {
      if (users[i].email == email) {
        users[i] = UserModel(
          email: users[i].email,
          username: users[i].username,
          password: newPassword,
        );
        break;
      }
    }
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String encoded = json.encode(users.map((e) => e.toJson()).toList());
    await prefs.setString(_userListKey, encoded);
  }
}
