import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/transaction_model.dart';
import '../models/user_model_login.dart';
import '../services/user_services.dart';

class SharedPrefs {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  // Key cho transactions & avatar
  static const keyHomeData = 'home_data';
  static const String keyAvatar = 'avatar_path';

  // Key cho user profile
  static const String keyName = 'user_name';
  static const String keyEmail = 'user_email';
  static const String keyPassword = 'user_password';
  static const String keyDateOfBirth = 'user_date_of_birth';
  static const String keyCountry = 'user_country';
  static const String keyProfileImagePath = 'user_profile_image_path';

  // Avatar path
  Future<String?> getAvatarPath() async {
    final prefs = await _prefs;
    return prefs.getString(keyAvatar);
  }

  Future<void> saveAvatarPath(String path) async {
    final prefs = await _prefs;
    await prefs.setString(keyAvatar, path);
  }

  // Transactions
  static Future<String?> _getKeyTransactions() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString(keyEmail);
    if (email == null) return null;
    return 'transactions_$email';
  }

  static Future<void> savetransactions(
    List<TransactionModel> transactions,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _getKeyTransactions();
    if (key == null) return;
    final jsonList = transactions.map((t) => jsonEncode(t.toJson())).toList();
    await prefs.setStringList(key, jsonList);
  }

  static Future<List<TransactionModel>> gettransactions() async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _getKeyTransactions();
    if (key == null) return [];

    final jsonList = prefs.getStringList(key);
    if (jsonList == null) return [];
    return jsonList.map((json) {
      final map = jsonDecode(json);
      return TransactionModel.fromJson(map);
    }).toList();
  }

  static Future<void> saveUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyEmail, user.email);
    await prefs.setString(keyName, user.username);
    await prefs.setString(keyPassword, user.password);
  }

  static Future<UserModel?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString(keyEmail);
    final username = prefs.getString(keyName);
    final password = prefs.getString(keyPassword);

    if (email != null && username != null && password != null) {
      return UserModel(email: email, username: username, password: password);
    }
    return null;
  }
  //lưu & load user profile

  Future<void> saveUserProfile({
    required String name,
    required String email,
    required String password,
    DateTime? dateOfBirth,
    String? country,
    String? profileImagePath,
  }) async {
    final prefs = await _prefs;
    await prefs.setString(keyName, name);
    await prefs.setString(keyEmail, email);
    await prefs.setString(keyPassword, password);

    if (dateOfBirth != null) {
      await prefs.setString(keyDateOfBirth, dateOfBirth.toIso8601String());
    }

    if (country != null) {
      await prefs.setString(keyCountry, country);
    }

    if (profileImagePath != null) {
      await prefs.setString(keyProfileImagePath, profileImagePath);
      await prefs.setString(keyAvatar, profileImagePath);
    }

    // --- Đồng bộ thông tin user cho chức năng đăng nhập ---
    await SharedPrefs.saveUser(
      UserModel(email: email, username: name, password: password),
    );
    // --- Đồng bộ password vào danh sách user_list ---
    await UserService.updateUserPassword(email, password);
    // ------------------------------------------------------
  }

  Future<Map<String, dynamic>> loadUserProfile() async {
    final prefs = await _prefs;

    final name = prefs.getString(keyName);
    final email = prefs.getString(keyEmail);
    final password = prefs.getString(keyPassword);
    final dobString = prefs.getString(keyDateOfBirth);
    final country = prefs.getString(keyCountry);
    final profileImagePath = prefs.getString(keyProfileImagePath);

    DateTime? dateOfBirth;
    if (dobString != null) {
      dateOfBirth = DateTime.tryParse(dobString);
    }

    return {
      'name': name,
      'email': email,
      'password': password,
      'dateOfBirth': dateOfBirth,
      'country': country,
      'profileImagePath': profileImagePath,
    };
  }

  Future<void> saveUserProfileImagePath(String path) async {
    final prefs = await _prefs;
    await prefs.setString(keyProfileImagePath, path);
  }

  Future<String?> getUserProfileImagePath() async {
    final prefs = await _prefs;
    return prefs.getString(keyProfileImagePath);
  }
}
